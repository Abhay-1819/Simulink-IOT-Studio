import { GoogleGenAI, Type } from "@google/genai";
import { SimulationConfig } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function generateSimulationConfig(prompt: string): Promise<SimulationConfig> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `
      You are an IoT simulation expert. Convert the following user request into a structured simulation configuration.
      
      User Request: "${prompt}"
      
      Special Instructions for 5G D2D/Cellular requests:
      1. Include three devices: "UE1" (mobile), "UE2" (mobile), and "gNB" (gateway).
      2. Set logicType to "d2d".
      3. Include metrics: "d2dThroughput" (Mbps), "cellThroughput" (Mbps), "optimalThroughput" (Mbps), and "mode" (Binary).
      4. Include controls for "txPower" (dBm) for UE1 and gNB.
      
      The configuration should include:
      1. A scenario name and description.
      2. A list of devices with their initial positions (x, y from 0-1000) and parameters.
      3. A list of metrics to track (e.g., signal strength, battery, latency).
      4. A list of controls for the user to interact with.
      5. A logicType ('d2d', 'star', 'mesh', or 'custom').
      
      Return ONLY the JSON object.
    `,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          scenarioName: { type: Type.STRING },
          description: { type: Type.STRING },
          logicType: { type: Type.STRING, enum: ['d2d', 'star', 'mesh', 'custom'] },
          devices: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                name: { type: Type.STRING },
                type: { type: Type.STRING, enum: ['mobile', 'gateway', 'sensor', 'actuator', 'satellite'] },
                x: { type: Type.NUMBER },
                y: { type: Type.NUMBER },
                params: { type: Type.OBJECT, additionalProperties: { type: Type.NUMBER } }
              },
              required: ['id', 'name', 'type', 'x', 'y', 'params']
            }
          },
          metrics: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                label: { type: Type.STRING },
                unit: { type: Type.STRING },
                color: { type: Type.STRING }
              },
              required: ['id', 'label', 'unit', 'color']
            }
          },
          controls: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                label: { type: Type.STRING },
                min: { type: Type.NUMBER },
                max: { type: Type.NUMBER },
                step: { type: Type.NUMBER },
                targetDeviceId: { type: Type.STRING },
                paramKey: { type: Type.STRING }
              },
              required: ['id', 'label', 'min', 'max', 'step', 'paramKey']
            }
          }
        },
        required: ['scenarioName', 'description', 'logicType', 'devices', 'metrics', 'controls']
      }
    }
  });

  try {
    return JSON.parse(response.text || '{}') as SimulationConfig;
  } catch (e) {
    console.error("Failed to parse Gemini response", e);
    throw new Error("Failed to generate simulation configuration.");
  }
}
