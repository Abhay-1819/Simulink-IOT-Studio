import React, { useState } from 'react';
import { SimulationConfig } from './types';
import { generateSimulationConfig } from './services/geminiService';
import { useSimulation } from './hooks/useSimulation';
import { SimulationCanvas } from './components/SimulationCanvas';
import { MetricChart } from './components/MetricChart';
import { ControlPanel } from './components/ControlPanel';
import { PromptBar } from './components/PromptBar';
import { Activity, Settings, Info, Play, Pause, RefreshCw, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [config, setConfig] = useState<SimulationConfig | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const { state, updateDeviceParam, toggleSimulation } = useSimulation(config);

  const handleGenerate = async (prompt: string) => {
    setIsGenerating(true);
    try {
      const newConfig = await generateSimulationConfig(prompt);
      setConfig(newConfig);
    } catch (error) {
      console.error(error);
      alert("Failed to generate simulation. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const deviceParams = state.devices.reduce((acc, d) => {
    acc[d.id] = d.params;
    return acc;
  }, {} as Record<string, Record<string, number>>);

  return (
    <div className="h-screen flex flex-col bg-[#f0f0f0] text-neutral-900 font-sans overflow-hidden">
      {/* Simulink Toolbar */}
      <header className="h-12 bg-[#e1e1e1] border-b border-neutral-300 flex items-center px-4 justify-between shadow-sm z-50">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-[#d95319] rounded flex items-center justify-center">
              <Activity className="text-white" size={14} />
            </div>
            <span className="font-bold text-sm text-neutral-700">Simulink IoT Studio</span>
          </div>
          
          <div className="h-6 w-[1px] bg-neutral-300 mx-2" />
          
          <div className="flex items-center gap-1">
            <button 
              onClick={toggleSimulation}
              disabled={!config}
              className={`p-1.5 rounded hover:bg-neutral-200 transition-colors ${state.isRunning ? 'text-blue-600' : 'text-neutral-500'}`}
              title={state.isRunning ? "Pause" : "Run"}
            >
              {state.isRunning ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" />}
            </button>
            <button className="p-1.5 rounded hover:bg-neutral-200 text-neutral-500" title="Step">
              <Activity size={18} />
            </button>
            <button 
              onClick={() => setConfig(null)}
              className="p-1.5 rounded hover:bg-neutral-200 text-neutral-500" 
              title="Stop"
            >
              <RefreshCw size={18} />
            </button>
          </div>
        </div>

        <div className="flex-1 max-w-xl px-4">
          <PromptBar onGenerate={handleGenerate} isGenerating={isGenerating} />
        </div>

        <div className="flex items-center gap-3">
          <button className="p-1.5 rounded hover:bg-neutral-200 text-neutral-500">
            <Settings size={18} />
          </button>
          <div className="text-[10px] font-mono text-neutral-500 bg-neutral-200 px-2 py-1 rounded border border-neutral-300">
            T=10.000
          </div>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Library Browser */}
        <aside className="w-64 bg-[#f8f8f8] border-r border-neutral-300 flex flex-col">
          <div className="p-3 border-b border-neutral-300 bg-[#e9e9e9] text-[11px] font-bold uppercase tracking-wider text-neutral-600">
            Library Browser
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-4">
            {['Sources', 'Sinks', 'Math Operations', 'IoT Devices', 'D2D Protocols'].map(cat => (
              <div key={cat} className="space-y-1">
                <div className="flex items-center gap-1 text-[11px] font-semibold text-neutral-500 px-2">
                  <Info size={10} /> {cat}
                </div>
                <div className="grid grid-cols-2 gap-1">
                  {[1, 2].map(i => (
                    <div key={i} className="h-12 bg-white border border-neutral-200 rounded flex items-center justify-center text-[9px] text-neutral-400 hover:border-blue-400 cursor-grab">
                      Block {i}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </aside>

        {/* Main Canvas Area */}
        <main className="flex-1 relative bg-white overflow-hidden flex flex-col">
          <div className="flex-1 relative">
            <AnimatePresence mode="wait">
              {!config ? (
                <motion.div 
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="absolute inset-0 flex flex-col items-center justify-center p-12 text-center"
                >
                  <div className="w-24 h-24 bg-neutral-100 rounded-3xl flex items-center justify-center mb-6 border-2 border-dashed border-neutral-300">
                    <Sparkles className="text-neutral-300" size={40} />
                  </div>
                  <h2 className="text-2xl font-bold text-neutral-400 mb-2">Empty Model</h2>
                  <p className="text-neutral-500 max-w-md">
                    Use the prompt bar above to describe your IoT simulation. 
                    Simulink will automatically generate the block diagram for you.
                  </p>
                </motion.div>
              ) : (
                <motion.div 
                  key="canvas"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="absolute inset-0"
                >
                  <SimulationCanvas 
                    devices={state.devices} 
                    mode={state.history[state.history.length - 1]?.metrics.mode} 
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Bottom Scope Area */}
          <div className="h-64 bg-[#f8f8f8] border-t border-neutral-300 flex flex-col">
            <div className="p-2 border-b border-neutral-300 bg-[#e9e9e9] flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-600">Scope / Diagnostic Viewer</span>
              <div className="flex gap-2">
                {config?.metrics.map(m => (
                  <div key={m.id} className="flex items-center gap-1 px-2 py-0.5 bg-white border border-neutral-200 rounded text-[10px]">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: m.color }} />
                    {m.label}
                  </div>
                ))}
              </div>
            </div>
            <div className="flex-1 p-4">
              {config && <MetricChart data={state.history} metrics={config.metrics} />}
            </div>
          </div>
        </main>

        {/* Property Inspector */}
        <aside className="w-72 bg-[#f8f8f8] border-l border-neutral-300 flex flex-col">
          <div className="p-3 border-b border-neutral-300 bg-[#e9e9e9] text-[11px] font-bold uppercase tracking-wider text-neutral-600">
            Property Inspector
          </div>
          <div className="flex-1 overflow-y-auto p-4">
            {config ? (
              <div className="space-y-6">
                <div className="space-y-2">
                  <div className="text-[10px] font-bold text-neutral-400 uppercase">Model Info</div>
                  <div className="p-3 bg-white border border-neutral-200 rounded text-xs text-neutral-600 leading-relaxed">
                    {config.description}
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="text-[10px] font-bold text-neutral-400 uppercase">Block Parameters</div>
                  <ControlPanel 
                    controls={config.controls} 
                    onUpdate={updateDeviceParam} 
                    deviceParams={deviceParams}
                  />
                </div>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-neutral-400 text-xs italic">
                No block selected
              </div>
            )}
          </div>
        </aside>
      </div>
      
      {/* Footer Status Bar */}
      <footer className="h-6 bg-[#007acc] text-white flex items-center px-3 justify-between text-[10px] font-medium">
        <div className="flex items-center gap-4">
          <span>Ready</span>
          <div className="h-3 w-[1px] bg-white/30" />
          <span>ODE45 (Variable-step)</span>
        </div>
        <div className="flex items-center gap-4">
          <span>100%</span>
          <div className="h-3 w-[1px] bg-white/30" />
          <span>UTF-8</span>
        </div>
      </footer>
    </div>
  );
}
