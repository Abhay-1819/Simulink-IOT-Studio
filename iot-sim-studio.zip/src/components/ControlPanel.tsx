import React from 'react';
import { Control } from '../types';

interface Props {
  controls: Control[];
  onUpdate: (deviceId: string, key: string, value: number) => void;
  deviceParams: Record<string, Record<string, number>>;
}

export const ControlPanel: React.FC<Props> = ({ controls, onUpdate, deviceParams }) => {
  return (
    <div className="space-y-2">
      {controls.map((control) => {
        const currentValue = deviceParams[control.targetDeviceId || '']?.[control.paramKey] ?? control.min;
        
        return (
          <div key={control.id} className="flex flex-col gap-1">
            <div className="flex justify-between items-center px-1">
              <label className="text-[10px] font-bold text-neutral-500 uppercase tracking-tight">
                {control.label}
              </label>
              <span className="text-[10px] font-mono font-bold text-blue-700">{currentValue.toFixed(2)}</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="range"
                min={control.min}
                max={control.max}
                step={control.step}
                value={currentValue}
                onChange={(e) => onUpdate(control.targetDeviceId || '', control.paramKey, parseFloat(e.target.value))}
                className="flex-1 h-1 bg-neutral-300 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};
