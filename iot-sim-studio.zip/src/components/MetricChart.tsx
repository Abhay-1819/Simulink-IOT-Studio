import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Metric } from '../types';

interface Props {
  data: any[];
  metrics: Metric[];
}

export const MetricChart: React.FC<Props> = ({ data, metrics }) => {
  return (
    <div className="h-full w-full bg-black p-2 rounded border border-neutral-400 shadow-inner">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="0" stroke="#333" />
          <XAxis 
            dataKey="timestamp" 
            hide 
          />
          <YAxis 
            stroke="#00ff00" 
            fontSize={9} 
            tickFormatter={(val) => val.toFixed(1)}
            domain={['auto', 'auto']}
            axisLine={false}
            tickLine={false}
          />
          <Tooltip 
            contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #444', borderRadius: '4px', fontSize: '10px', color: '#fff' }}
            itemStyle={{ fontSize: '10px' }}
            labelStyle={{ display: 'none' }}
          />
          {metrics.map((m) => (
            <Line
              key={m.id}
              type="stepAfter"
              dataKey={`metrics.${m.id}`}
              stroke={m.color === '#3b82f6' ? '#00ffff' : m.color} // Brighten colors for black bg
              strokeWidth={1.5}
              dot={false}
              isAnimationActive={false}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
