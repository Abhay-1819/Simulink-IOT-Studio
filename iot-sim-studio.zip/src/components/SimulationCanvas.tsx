import React from 'react';
import { Device } from '../types';
import { Smartphone, Router, Cpu, Activity, Satellite } from 'lucide-react';
import { motion } from 'motion/react';

const icons = {
  mobile: Smartphone,
  gateway: Router,
  sensor: Cpu,
  actuator: Activity,
  satellite: Satellite,
};

interface Props {
  devices: Device[];
  mode?: number; // 1 for D2D, 0 for Cellular
}

export const SimulationCanvas: React.FC<Props> = ({ devices, mode }) => {
  return (
    <div className="relative w-full h-full bg-[#f5f5f5] overflow-hidden shadow-inner">
      {/* Grid Background */}
      <div className="absolute inset-0 opacity-[0.05]" 
           style={{ backgroundImage: 'linear-gradient(#000 1px, transparent 1px), linear-gradient(90deg, #000 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
      
      {/* Connections & Signal Lines */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none">
        {devices.length >= 2 && devices.map((device, idx) => {
          const isD2DMode = mode === 1;
          const isCellMode = mode === 0;
          
          const ue1 = devices.find(d => d.name.includes('UE1') || d.id === 'ue1') || devices[0];
          const ue2 = devices.find(d => d.name.includes('UE2') || d.id === 'ue2') || devices[1];
          const gnb = devices.find(d => d.type === 'gateway' || d.name.includes('gNB'));

          const connections: Array<{ from: Device; to: Device; active: boolean; color: string }> = [];

          if (ue1 && ue2 && gnb) {
            // D2D Path
            connections.push({ from: ue1, to: ue2, active: isD2DMode, color: '#007acc' });
            // Cellular Path
            connections.push({ from: ue1, to: gnb, active: isCellMode, color: '#d95319' });
            connections.push({ from: gnb, to: ue2, active: isCellMode, color: '#d95319' });
          } else if (devices.length === 2 && idx === 0) {
            connections.push({ from: devices[0], to: devices[1], active: true, color: '#007acc' });
          }

          return connections.map((conn, cIdx) => {
            const x1 = (conn.from.x / 1000) * 100;
            const y1 = (conn.from.y / 1000) * 100;
            const x2 = (conn.to.x / 1000) * 100;
            const y2 = (conn.to.y / 1000) * 100;

            return (
              <React.Fragment key={`conn-${conn.from.id}-${conn.to.id}-${cIdx}`}>
                {/* Signal Line */}
                <line
                  x1={`${x1}%`}
                  y1={`${y1}%`}
                  x2={`${x2}%`}
                  y2={`${y2}%`}
                  stroke={conn.active ? conn.color : '#ccc'}
                  strokeWidth={conn.active ? 2 : 1}
                  strokeDasharray={conn.active ? "0" : "4 4"}
                  className="transition-all duration-500"
                />
                
                {/* Animated Signal Packets */}
                {conn.active && [0, 1, 2].map((i) => (
                  <motion.circle
                    key={`packet-${conn.from.id}-${conn.to.id}-${i}`}
                    r="3"
                    fill={conn.color}
                    initial={{ opacity: 0 }}
                    animate={{ 
                      cx: [`${x1}%`, `${x2}%`],
                      cy: [`${y1}%`, `${y2}%`],
                      opacity: [0, 1, 1, 0],
                    }}
                    transition={{ 
                      duration: 1.5, 
                      repeat: Infinity, 
                      delay: i * 0.5,
                      ease: "linear" 
                    }}
                  />
                ))}
              </React.Fragment>
            );
          });
        })}
      </svg>

      {devices.map((device) => {
        const Icon = icons[device.type] || Cpu;
        return (
          <motion.div
            key={device.id}
            className="absolute flex flex-col items-center"
            style={{ 
              left: `${(device.x / 1000) * 100}%`, 
              top: `${(device.y / 1000) * 100}%`,
              transform: 'translate(-50%, -50%)'
            }}
            layout
          >
            {/* Simulink Block */}
            <div className="relative group">
              <div className="w-16 h-16 bg-white border-2 border-neutral-800 shadow-sm flex items-center justify-center text-neutral-800 hover:border-blue-500 transition-colors">
                <Icon size={24} />
                
                {/* Ports */}
                <div className="absolute -left-1 top-1/2 -translate-y-1/2 w-2 h-2 bg-neutral-800 rotate-45" />
                <div className="absolute -right-1 top-1/2 -translate-y-1/2 w-2 h-2 bg-neutral-800 rotate-45" />
              </div>
              
              <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 whitespace-nowrap text-[10px] font-bold text-neutral-600 bg-white/80 px-1 rounded">
                {device.name}
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
};
