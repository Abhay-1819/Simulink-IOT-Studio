import React, { useState } from 'react';
import { Sparkles, Loader2 } from 'lucide-react';

interface Props {
  onGenerate: (prompt: string) => Promise<void>;
  isGenerating: boolean;
}

export const PromptBar: React.FC<Props> = ({ onGenerate, isGenerating }) => {
  const [prompt, setPrompt] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim() && !isGenerating) {
      onGenerate(prompt);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="relative flex items-center w-full max-w-lg">
      <input
        type="text"
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder="Enter simulation prompt..."
        className="w-full bg-white border border-neutral-300 rounded px-3 py-1 text-xs text-neutral-800 placeholder-neutral-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all shadow-sm"
        disabled={isGenerating}
      />
      <button
        type="submit"
        disabled={isGenerating || !prompt.trim()}
        className="absolute right-1 top-1 bottom-1 px-2 bg-[#d95319] hover:bg-[#c04815] disabled:bg-neutral-200 disabled:text-neutral-400 text-white rounded text-[10px] font-bold transition-all flex items-center gap-1"
      >
        {isGenerating ? (
          <Loader2 className="animate-spin" size={12} />
        ) : (
          <>
            <Sparkles size={12} />
            <span>Generate</span>
          </>
        )}
      </button>
    </form>
  );
};
