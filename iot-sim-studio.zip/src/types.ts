
export type DeviceType = 'mobile' | 'gateway' | 'sensor' | 'actuator' | 'satellite';

export interface Device {
  id: string;
  name: string;
  type: DeviceType;
  x: number;
  y: number;
  params: Record<string, number>;
}

export interface Metric {
  id: string;
  label: string;
  unit: string;
  color: string;
}

export interface Control {
  id: string;
  label: string;
  min: number;
  max: number;
  step: number;
  targetDeviceId?: string;
  paramKey: string;
}

export interface SimulationConfig {
  scenarioName: string;
  description: string;
  devices: Device[];
  metrics: Metric[];
  controls: Control[];
  // Logic parameters for the engine
  logicType: 'd2d' | 'star' | 'mesh' | 'custom';
}

export interface SimulationState {
  devices: Device[];
  history: Array<{
    timestamp: number;
    metrics: Record<string, number>;
  }>;
  isRunning: boolean;
}
