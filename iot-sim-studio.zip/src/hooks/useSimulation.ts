import { useState, useEffect, useCallback, useRef } from 'react';
import { SimulationConfig, SimulationState, Device } from '../types';

export function useSimulation(config: SimulationConfig | null) {
  const [state, setState] = useState<SimulationState>({
    devices: [],
    history: [],
    isRunning: false,
  });

  const stateRef = useRef(state);
  stateRef.current = state;

  useEffect(() => {
    if (config) {
      setState({
        devices: config.devices,
        history: [],
        isRunning: true,
      });
    }
  }, [config]);

  const updateSimulation = useCallback(() => {
    if (!config || !stateRef.current.isRunning) return;

    const currentDevices = [...stateRef.current.devices];
    const newMetrics: Record<string, number> = {};

    // Logic based on logicType
    if (config.logicType === 'd2d' || config.logicType === 'custom') {
      const ue1 = currentDevices.find(d => d.name.includes('UE1') || d.id === 'ue1') || currentDevices[0];
      const ue2 = currentDevices.find(d => d.name.includes('UE2') || d.id === 'ue2') || currentDevices[1];
      const gnb = currentDevices.find(d => d.type === 'gateway' || d.name.includes('gNB'));

      if (ue1 && ue2) {
        // --- Parameters from MATLAB ---
        const fc = 3.5e9;
        const B = 20e6;
        const Pt_UE = ue1.params.txPower ?? 23;
        const Pt_gNB = gnb?.params.txPower ?? 43;
        const N0_dBm = -174;
        const NF_dB = 7;
        const N_dBm = N0_dBm + 10 * Math.log10(B) + NF_dB;

        // --- Path Loss Model (3GPP UMi NLOS) ---
        const getPL = (d: number) => 35.3 * Math.log10(Math.max(1, d)) + 22.4 + 21.3 * Math.log10(fc / 1e9);

        // --- D2D Path ---
        const d_D2D = Math.sqrt(Math.pow(ue1.x - ue2.x, 2) + Math.pow(ue1.y - ue2.y, 2)) / 10; // scale for meters
        const PL_D2D = getPL(d_D2D);
        const SINR_D2D_dB = (Pt_UE - PL_D2D) - N_dBm;
        const C_D2D = (B * Math.log2(1 + Math.pow(10, SINR_D2D_dB / 10))) / 1e6;

        // --- Cellular Path (via gNB) ---
        if (gnb) {
          const d_ue1_gnb = Math.sqrt(Math.pow(ue1.x - gnb.x, 2) + Math.pow(ue1.y - gnb.y, 2)) / 10;
          const d_ue2_gnb = Math.sqrt(Math.pow(ue2.x - gnb.x, 2) + Math.pow(ue2.y - gnb.y, 2)) / 10;
          
          const PL_ul = getPL(d_ue1_gnb);
          const PL_dl = getPL(d_ue2_gnb);

          const SINR_UL_dB = (Pt_UE - PL_ul) - N_dBm;
          const SINR_DL_dB = (Pt_gNB - PL_dl) - N_dBm;
          
          // Bottleneck SINR
          const SINR_cell_dB = Math.min(SINR_UL_dB, SINR_DL_dB);
          const C_cell = (B * Math.log2(1 + Math.pow(10, SINR_cell_dB / 10))) / 1e6;

          newMetrics.d2dThroughput = C_D2D;
          newMetrics.cellThroughput = C_cell;
          newMetrics.optimalThroughput = Math.max(C_D2D, C_cell);
          newMetrics.mode = C_D2D >= C_cell ? 1 : 0; // 1 for D2D, 0 for Cellular
          newMetrics.d2dDistance = d_D2D;
        } else {
          newMetrics.throughput = C_D2D;
          newMetrics.sinr = SINR_D2D_dB;
        }
      }
    } else if (config.logicType === 'star') {
      const gateway = currentDevices.find(d => d.type === 'gateway');
      const sensors = currentDevices.filter(d => d.type === 'sensor');
      
      if (gateway) {
        let avgBattery = 0;
        let totalThroughput = 0;
        
        sensors.forEach(s => {
          const dist = Math.sqrt(Math.pow(s.x - gateway.x, 2) + Math.pow(s.y - gateway.y, 2));
          avgBattery += (s.params.battery || 100) - (dist / 1000);
          totalThroughput += Math.max(0, 100 - (dist / 5));
        });
        
        newMetrics.battery = sensors.length > 0 ? avgBattery / sensors.length : 100;
        newMetrics.throughput = totalThroughput;
      }
    } else if (config.logicType === 'mesh') {
      newMetrics.reliability = 95 + Math.random() * 5;
      newMetrics.hopCount = 2 + Math.random() * 1;
    } else {
      // Generic logic for other types
      config.metrics.forEach(m => {
        newMetrics[m.id] = 50 + Math.random() * 10;
      });
    }

    setState(prev => ({
      ...prev,
      history: [...prev.history, { timestamp: Date.now(), metrics: newMetrics }].slice(-50),
    }));
  }, [config]);

  useEffect(() => {
    const interval = setInterval(updateSimulation, 500);
    return () => clearInterval(interval);
  }, [updateSimulation]);

  const updateDeviceParam = (deviceId: string, key: string, value: number) => {
    setState(prev => ({
      ...prev,
      devices: prev.devices.map(d => 
        d.id === deviceId ? { ...d, params: { ...d.params, [key]: value } } : d
      )
    }));
  };

  const toggleSimulation = () => {
    setState(prev => ({ ...prev, isRunning: !prev.isRunning }));
  };

  return { state, updateDeviceParam, toggleSimulation };
}
